// KIỂM TRA I2C VÀ CHIP ID CỦA BME280 TRÊN ESP32.
//
// Sketch này dùng để chạy TRƯỚC khi nạp firmware chính: nó kiểm tra cảm
// biến đã được nối đúng và nhận diện đúng chưa, tránh trường hợp mang
// firmware lấy mẫu lên board mà cảm biến chưa cắm đúng.
//
// Phần cứng: SDA = GPIO21, SCL = GPIO22 (chân I2C mặc định của ESP32).
//
// Về địa chỉ I2C của BME280: tùy cách nối chân SDO trên module,
// cảm biến có thể nằm ở một trong hai địa chỉ:
//   SDO nối GND                     -> địa chỉ 0x76
//   SDO nối 3V3 (hoặc để thả nổi)   -> địa chỉ 0x77
//
// LỖI ĐÃ SỬA: bản cũ chỉ hỏi đúng địa chỉ 0x76, nên nếu module cấu hình
// ở 0x77 thì chương trình sẽ báo "không thấy cảm biến" dù cảm biến vẫn
// hoạt động tốt, gây chẩn đoán sai khi đấu nối. Bản này kiểm tra CẢ HAI
// địa chỉ rồi mới đưa ra kết luận.
#include <Wire.h>

const uint8_t PIN_SDA = 21;   // chân SDA của ESP32
const uint8_t PIN_SCL = 22;   // chân SCL của ESP32

// Danh sách 2 địa chỉ có thể có của BME280 trên bus I2C.
const uint8_t BME280_ADDR[2] = { 0x76, 0x77 };

// Kiểm tra nhanh "có thiết bị nào trả lời ở địa chỉ này không".
// Cách làm: bắt đầu một phiên truyền tới addr rồi kết thúc ngay;
// nếu endTransmission() trả về 0 nghĩa là có thiết bị ACK địa chỉ đó.
bool devicePresent(uint8_t addr) {
  Wire.beginTransmission(addr);
  return Wire.endTransmission() == 0;
}

// Đọc thanh ghi 0xD0 (chip ID) của cảm biến để biết chính xác loại chip.
// Thanh ghi 0xD0 của dòng Bosch luôn trả về mã nhận dạng:
//   0x60 = BME280 (đủ nhiệt độ + độ ẩm + áp suất, đúng chip cần dùng)
//   0x58 = BMP280 (chỉ có nhiệt độ + áp suất, KHÔNG có độ ẩm)
// Hàm trả về 0x00 khi giao tiếp I2C thất bại (thiết bị NACK hoặc mất bus),
// và 0x00 không trùng với mã chip hợp lệ nào nên có thể dùng làm mã lỗi.
uint8_t readChipId(uint8_t addr) {
  Wire.beginTransmission(addr);
  Wire.write(0xD0);                  // gửi địa chỉ thanh ghi muốn đọc
  // endTransmission(false): KHÔNG phát tín hiệu STOP, giữ bus cho lượt
  // đọc tiếp theo (repeated start). Đây là cách chuẩn khi đọc một thanh
  // ghi qua I2C: viết địa chỉ thanh ghi trước, rồi đọc nội dung sau.
  if (Wire.endTransmission(false) != 0) return 0x00;
  // Yêu cầu 1 byte dữ liệu từ cảm biến. Ép kiểu (uint8_t) tường minh cho
  // cả 2 tham số để tránh gọi nhầm overload của requestFrom — lỗi phổ biến
  // khi biên dịch cho ESP32 core (trả về số byte nhận được phải là 1).
  if (Wire.requestFrom((uint8_t)addr, (uint8_t)1) != 1) return 0x00;
  return (uint8_t)Wire.read();
}

void setup() {
  Serial.begin(115200);
  delay(1000);                       // chờ serial monitor kịp kết nối rồi mới in, tránh mất dòng đầu
  Serial.println();
  Serial.println("I2C scan + BME280 chip-ID check (SDA=21, SCL=22)");
  Wire.begin(PIN_SDA, PIN_SCL);      // khởi động I2C trên đúng cặp chân đã khai báo
}

void loop() {
  bool found = false;   // cờ đánh dấu "trên bus có thiết bị nào hay không"

  Serial.println();
  Serial.println("Scanning I2C bus...");

  // Quét toàn bộ dải địa chỉ thiết bị thông thường: 1 đến 126.
  // (0x00 là địa chỉ general-call và 0x7F không phải địa chỉ thiết bị
  // thông thường nên không cần quét.)
  for (uint8_t a = 1; a < 127; a++) {
    if (devicePresent(a)) {
      found = true;
      Serial.printf("Found 0x%02X\n", a);
    }
  }

  if (!found) {
    // Bus trống: nguyên nhân gần như luôn nằm ở phần cứng (sai dây, thiếu
    // nguồn, thiếu điện trở kéo lên SDA/SCL), chứ không phải lỗi code.
    Serial.println("No I2C device found.");
    Serial.println("Check: VCC->3V3, GND->GND, SDA->GPIO21, SCL->GPIO22, pull-ups on SDA/SCL.");
  }

  // Định danh chip nằm tại từng địa chỉ BME280 có thể có.
  // Vòng này vẫn chạy kể cả khi quét trên không thấy gì, để in chi tiết
  // rõ hơn cho các địa chỉ quan trọng (0x76 / 0x77).
  for (uint8_t i = 0; i < 2; i++) {
    uint8_t addr = BME280_ADDR[i];
    if (devicePresent(addr)) {
      uint8_t id = readChipId(addr);
      if (id == 0x60) {
        Serial.printf("0x%02X: chip ID 0x60 -> BME280 (OK)\n", addr);
      } else if (id == 0x58) {
        // Cắm nhầm BMP280: firmware chính sẽ đọc độ ẩm thất bại vì chip
        // này không có cảm biến ẩm, nên phải phát hiện ngay từ bước này.
        Serial.printf("0x%02X: chip ID 0x58 -> BMP280 (no humidity sensor!)\n", addr);
      } else {
        Serial.printf("0x%02X: chip ID 0x%02X (not a BME280)\n", addr, id);
      }
    }
  }

  delay(3000);   // sau 3 giây quét lại lần nữa, tiện theo dõi lúc đang cắm/rút dây
}
